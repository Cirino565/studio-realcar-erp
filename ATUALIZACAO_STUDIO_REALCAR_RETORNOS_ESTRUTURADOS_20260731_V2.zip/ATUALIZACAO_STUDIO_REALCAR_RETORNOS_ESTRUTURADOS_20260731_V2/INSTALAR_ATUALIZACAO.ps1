﻿param(
    [string]$ProjectPath = (Get-Location).Path
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "============================================================"
Write-Host " ATUALIZACAO V2, RETORNOS ESTRUTURADOS"
Write-Host "============================================================"
Write-Host ""

$PackageRoot = $PSScriptRoot
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectPath).Path

if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot ".git"))) {
    throw "Execute o instalador na raiz do projeto Git."
}

if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "package.json"))) {
    throw "package.json nao encontrado na raiz do projeto."
}

Push-Location $ProjectRoot
try {
    $Branch = (git branch --show-current).Trim()
    if ($LASTEXITCODE -ne 0) {
        throw "Nao foi possivel identificar a branch atual."
    }

    if ($Branch -ne "main") {
        throw "A branch atual e '$Branch'. Mude para main antes de instalar."
    }

    $TrackedChanges = @(git status --porcelain --untracked-files=no)
    if ($LASTEXITCODE -ne 0) {
        throw "Nao foi possivel verificar o estado do Git."
    }

    if ($TrackedChanges.Count -gt 0) {
        Write-Host "Arquivos rastreados com alteracoes:" -ForegroundColor Yellow
        $TrackedChanges | ForEach-Object { Write-Host $_ }
        throw "O Git possui alteracoes rastreadas. Faça commit, restaure ou guarde essas alteracoes antes de instalar."
    }
}
finally {
    Pop-Location
}

$Files = @(
    [PSCustomObject]@{
        RelativePath = "actions\agendamento.actions.ts"
        OriginalHash = "CFFB6FE661266EC1D884385C0BE7CB5001C1A358A236D8D1A375B9F44B6F668F"
        UpdatedHash  = "12338E33401DC70D78A0C15743F273079D9AD4E8D9386D69461A29B87F67C4D5"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "app\(app)\page.tsx"
        OriginalHash = "2DC3D11C416FAE334E45A65E9BC1E99745BB60CB649D15AA75C4B5D4F896A863"
        UpdatedHash  = "12F42423209EBC7A2EA47ADDE2EF946FD6E82A2366DEB7CF1805CADDCB776B92"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "app\(app)\agenda\page.tsx"
        OriginalHash = "EE23FBFC896598D46CC02ED40528851787202ADBA3AD42AF8B8E7ED54E318BB7"
        UpdatedHash  = "28392C27F13274BC0239D9AA14B9DE90070DEBE61EC70451DE024D74B4B5B9F9"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "app\(app)\agenda\components\AgendaClient.tsx"
        OriginalHash = "68F2B153E46268CD7561768986F4DD706AC6E43342785BB425DA8EB553151953"
        UpdatedHash  = "6B0A52724C729D5775134412B96A85F80B00FEB4B5E4EA97D65007E8009FD0B1"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "app\(app)\agenda\components\AgendaCalendar.tsx"
        OriginalHash = "1F3A5B85107180635CD36F74016F20F9DE614115BEEECC845F057EC2498D015F"
        UpdatedHash  = "99A0D627C19E604D9064E3CF6B20A5637DCD93D92FF11B557BCD99B0E4D6A9A2"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "app\(app)\agenda\components\AppointmentDetailsModal.tsx"
        OriginalHash = "06436D7422C2FA99FD772756754E3879029361C330F56E2BAFD240AB76B45FF2"
        UpdatedHash  = "49B880F3228B8B89B511876D751733696C7E0BF0E4DEE384227C32B91AFEC459"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "app\(app)\agenda\components\AppointmentMessageModal.tsx"
        OriginalHash = "1F4EA25887BA283DE52B54083C03DF292C24849832B05EAA59325CD0E3AF7AC7"
        UpdatedHash  = "BBBF454A418177209EEBFF84A71EE2CBB0FF2FB79D5BECFF96554E73A0CDB201"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "app\(app)\agenda\components\FinalizarAtendimentoModal.tsx"
        OriginalHash = "E7B962FE32AF229212531B12A78A73FEB8F399B63F60B7B96D951C946CE8D893"
        UpdatedHash  = "4C14CDC0C6294E25FF80E91F0FCFFD8DAD15B22362C2226CC1183E0ABE438599"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "app\(app)\agenda\components\NovoAgendamentoModal.tsx"
        OriginalHash = "97167F20D54AF3BDAD8EFEA139EEE02979866D78311318B7CBA37912499BD708"
        UpdatedHash  = "B08D3256D35592A0E0A5C6AF42ED3627BC68D9011ACBA4962216664511895B3B"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "prisma\schema.prisma"
        OriginalHash = "2C863CAA15EA2622E6B7380051B9F5EFA9B5AD6EF08CEE46A8C46547496BD9C0"
        UpdatedHash  = "A51B32A38DB614601572CC25B7B958BF51FB1B12E3E448459D06772A569CC5A0"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "prisma\schema.sqlite.prisma"
        OriginalHash = "48400DC54B44E7B570821D457BF09F89D9AD5725D20454ECD89117A30BA20A2D"
        UpdatedHash  = "7B4A2C9BCFC74C5ED0E7DBC9C962064227F49B487E63918A02E685E583840A69"
        IsNew        = $false
    },
    [PSCustomObject]@{
        RelativePath = "prisma\migrations\20260731211500_agendamento_retorno_estruturado\migration.sql"
        OriginalHash = $null
        UpdatedHash  = "E45B2361AB2E3AFEC8524D2806B35019E88D8DD92E56D6681531250677FEA7CF"
        IsNew        = $true
    }
)

Write-Host "Validando arquivos e hashes do pacote..." -ForegroundColor Cyan

foreach ($File in $Files) {
    $TargetPath = Join-Path $ProjectRoot $File.RelativePath
    $PayloadPath = Join-Path (Join-Path $PackageRoot "payload") $File.RelativePath

    if (-not (Test-Path -LiteralPath $PayloadPath -PathType Leaf)) {
        throw "Arquivo ausente no pacote: $($File.RelativePath)"
    }

    $PayloadHash = (Get-FileHash -LiteralPath $PayloadPath -Algorithm SHA256).Hash
    if ($PayloadHash -ne $File.UpdatedHash) {
        throw "Falha na verificacao SHA-256 do pacote: $($File.RelativePath)"
    }

    if ($File.IsNew) {
        if (Test-Path -LiteralPath $TargetPath -PathType Leaf) {
            $CurrentHash = (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash
            if ($CurrentHash -ne $File.UpdatedHash) {
                throw "O novo arquivo ja existe com conteudo diferente: $($File.RelativePath)"
            }
        }
        continue
    }

    if (-not (Test-Path -LiteralPath $TargetPath -PathType Leaf)) {
        throw "Arquivo do projeto nao encontrado: $($File.RelativePath)"
    }

    $CurrentHash = (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash
    if ($CurrentHash -ne $File.OriginalHash -and $CurrentHash -ne $File.UpdatedHash) {
        throw "O arquivo esta diferente da versao analisada: $($File.RelativePath). Nenhuma alteracao foi aplicada."
    }
}

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$BackupRoot = Join-Path (Split-Path $ProjectRoot -Parent) "BACKUPS_STUDIO_REALCAR"
$BackupPath = Join-Path $BackupRoot "backup_retornos_estruturados_$Timestamp"
New-Item -ItemType Directory -Path $BackupPath -Force | Out-Null

$States = New-Object System.Collections.Generic.List[object]

foreach ($File in $Files) {
    $TargetPath = Join-Path $ProjectRoot $File.RelativePath
    $TargetExisted = Test-Path -LiteralPath $TargetPath -PathType Leaf

    $States.Add([PSCustomObject]@{
        RelativePath = $File.RelativePath
        TargetExisted = $TargetExisted
    })

    if ($TargetExisted) {
        $BackupFile = Join-Path $BackupPath $File.RelativePath
        $BackupDirectory = Split-Path $BackupFile -Parent
        New-Item -ItemType Directory -Path $BackupDirectory -Force | Out-Null
        Copy-Item -LiteralPath $TargetPath -Destination $BackupFile -Force
    }
}

try {
    foreach ($File in $Files) {
        $TargetPath = Join-Path $ProjectRoot $File.RelativePath
        $PayloadPath = Join-Path (Join-Path $PackageRoot "payload") $File.RelativePath
        $TargetDirectory = Split-Path $TargetPath -Parent
        New-Item -ItemType Directory -Path $TargetDirectory -Force | Out-Null

        if (Test-Path -LiteralPath $TargetPath -PathType Leaf) {
            $CurrentHash = (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash
            if ($CurrentHash -eq $File.UpdatedHash) {
                Write-Host "Ja atualizado: $($File.RelativePath)" -ForegroundColor DarkGray
                continue
            }
        }

        Copy-Item -LiteralPath $PayloadPath -Destination $TargetPath -Force

        $InstalledHash = (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash
        if ($InstalledHash -ne $File.UpdatedHash) {
            throw "Falha ao validar o arquivo instalado: $($File.RelativePath)"
        }

        Write-Host "Atualizado: $($File.RelativePath)" -ForegroundColor Green
    }

    Write-Host ""
    Write-Host "Executando build obrigatorio..." -ForegroundColor Cyan

    Push-Location $ProjectRoot
    try {
        & npm.cmd run build
        if ($LASTEXITCODE -ne 0) {
            throw "O build falhou."
        }

        Write-Host ""
        Write-Host "Executando verificacao de whitespace..." -ForegroundColor Cyan
        & git -c core.whitespace=cr-at-eol diff --check
        if ($LASTEXITCODE -ne 0) {
            throw "A verificacao git diff --check falhou."
        }
    }
    finally {
        Pop-Location
    }
}
catch {
    Write-Host ""
    Write-Host "Falha detectada. Restaurando o estado anterior..." -ForegroundColor Red

    foreach ($State in $States) {
        $TargetPath = Join-Path $ProjectRoot $State.RelativePath
        $BackupFile = Join-Path $BackupPath $State.RelativePath

        if ($State.TargetExisted) {
            if (Test-Path -LiteralPath $BackupFile -PathType Leaf) {
                $TargetDirectory = Split-Path $TargetPath -Parent
                New-Item -ItemType Directory -Path $TargetDirectory -Force | Out-Null
                Copy-Item -LiteralPath $BackupFile -Destination $TargetPath -Force
            }
        }
        elseif (Test-Path -LiteralPath $TargetPath -PathType Leaf) {
            Remove-Item -LiteralPath $TargetPath -Force
        }
    }

    $MigrationDirectory = Join-Path $ProjectRoot "prisma\migrations\20260731211500_agendamento_retorno_estruturado"
    if (Test-Path -LiteralPath $MigrationDirectory -PathType Container) {
        $RemainingItems = @(Get-ChildItem -LiteralPath $MigrationDirectory -Force)
        if ($RemainingItems.Count -eq 0) {
            Remove-Item -LiteralPath $MigrationDirectory -Force
        }
    }

    Write-Host "Restauracao concluida." -ForegroundColor Yellow
    throw
}

Write-Host ""
Write-Host "============================================================"
Write-Host " ATUALIZACAO V2 VALIDADA COM SUCESSO"
Write-Host "============================================================"
Write-Host ""
Write-Host "Backup criado em:"
Write-Host $BackupPath
Write-Host ""
Write-Host "A migration sera aplicada pelo Railway no deploy da main." -ForegroundColor Cyan
Write-Host "Nao execute prisma db push." -ForegroundColor Yellow
Write-Host ""
Write-Host "Revise com:"
Write-Host "git status"
Write-Host "git -c core.whitespace=cr-at-eol diff --check"
Write-Host ""
Write-Host "Depois, remova o ZIP e a pasta do instalador, faça commit e envie para main."
Write-Host 'Mensagem sugerida: git commit -m "Adiciona retornos estruturados na agenda"'
Write-Host ""
Write-Host "Acompanhe o Railway ate ACTIVE e execute os testes do LEIA-ME.txt."
Write-Host ""
