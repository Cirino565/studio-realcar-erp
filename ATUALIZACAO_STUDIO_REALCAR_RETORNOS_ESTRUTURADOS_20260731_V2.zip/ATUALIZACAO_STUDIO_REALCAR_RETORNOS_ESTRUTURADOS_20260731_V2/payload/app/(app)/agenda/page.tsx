import { canAccess, isAdminUser, requirePagePermission } from "@/lib/auth";
import { obterAreaPadraoAgendamento } from "@/lib/area-cliente";
import { prisma } from "@/lib/prisma";

import AgendaClient from "./components/AgendaClient";

type AgendaPageProps = {
  searchParams?:
    | Promise<Record<string, string | string[] | undefined>>
    | Record<string, string | string[] | undefined>;
};

function getParam(
  params: Record<string, string | string[] | undefined>,
  key: string,
) {
  const value = params[key];

  return Array.isArray(value) ? value[0] : value;
}

type AgendaViewMode = "day" | "week";

function getViewMode(value?: string): AgendaViewMode {
  return value === "week" ? "week" : "day";
}

function getDataSelecionada(value?: string) {
  if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return new Date();
  }

  const [year, month, day] = value.split("-").map(Number);

  return new Date(year, month - 1, day);
}

function toDateInput(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function inicioDoDia(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function fimDoDia(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
}

function inicioDaSemana(date: Date) {
  const result = inicioDoDia(date);
  result.setDate(result.getDate() - result.getDay());
  return result;
}

function fimDaSemana(date: Date) {
  const result = inicioDaSemana(date);
  result.setDate(result.getDate() + 7);
  return result;
}

function normalizarTexto(value?: string | null) {
  return (value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

function normalizarNaturezaAtendimento(
  value?: string | null,
): "PROCEDIMENTO" | "RETORNO" {
  return value === "RETORNO" ? "RETORNO" : "PROCEDIMENTO";
}

function encontrarProfissionalDoUsuario<
  T extends {
    id: number;
    nome: string;
    email?: string | null;
  },
>(usuario: { nome: string; email: string }, profissionais: T[]) {
  const emailUsuario = usuario.email.trim().toLowerCase();
  const nomeUsuario = normalizarTexto(usuario.nome);

  const porEmail = profissionais.find(
    (profissional) =>
      profissional.email?.trim().toLowerCase() === emailUsuario,
  );

  if (porEmail) {
    return porEmail;
  }

  const porNomeExato = profissionais.find(
    (profissional) => normalizarTexto(profissional.nome) === nomeUsuario,
  );

  if (porNomeExato) {
    return porNomeExato;
  }

  return profissionais.find((profissional) => {
    const nomeProfissional = normalizarTexto(profissional.nome);

    return (
      nomeUsuario.includes(nomeProfissional) ||
      nomeProfissional.includes(nomeUsuario)
    );
  });
}

export default async function AgendaPage({ searchParams }: AgendaPageProps) {
  const usuario = await requirePagePermission("agenda.visualizar");
  const usuarioAdmin = isAdminUser(usuario);
  const areaPadraoAgendamento = obterAreaPadraoAgendamento(
    usuario.nome,
    usuarioAdmin,
  );
  const podeEditarCliente = canAccess(usuario, "clientes.gerenciar");
  const podeRegistrarEvolucao = canAccess(usuario, "clientes.clinico");

  const resolvedSearchParams = searchParams ? await searchParams : {};

  const dataSelecionada = getDataSelecionada(
    getParam(resolvedSearchParams, "data"),
  );

  const viewMode = getViewMode(getParam(resolvedSearchParams, "view"));
  const inicioBusca =
    viewMode === "week" ? inicioDaSemana(dataSelecionada) : inicioDoDia(dataSelecionada);
  const fimBusca =
    viewMode === "week" ? fimDaSemana(dataSelecionada) : fimDoDia(dataSelecionada);

  const profissionalFiltroParam = getParam(
    resolvedSearchParams,
    "profissional",
  );

  const clienteIdParam = getParam(
    resolvedSearchParams,
    "clienteId",
  );

  const [clientes, profissionais, origensCliente, servicos, produtos, kits, configuracaoClinica] = await Promise.all([
    prisma.cliente.findMany({
      orderBy: { nome: "asc" },
      select: {
        id: true,
        nome: true,
        telefone: true,
        whatsapp: true,
        areaEstetica: true,
        areaCilios: true,
      },
    }),

    prisma.profissional.findMany({
      where: { status: "Ativa" },
      orderBy: [{ ordem: "asc" }, { nome: "asc" }],
      select: {
        id: true,
        nome: true,
        area: true,
        cor: true,
        telefone: true,
        email: true,
        status: true,
      },
    }),

    prisma.origemCliente.findMany({
      where: { status: "Ativa" },
      orderBy: [{ ordem: "asc" }, { nome: "asc" }],
      select: {
        id: true,
        nome: true,
      },
    }),

    prisma.procedimentoServico.findMany({
      where: { status: "Ativo" },
      orderBy: [{ nome: "asc" }, { id: "asc" }],
      select: {
        id: true,
        nome: true,
        categoria: true,
        duracaoPadrao: true,
        valorPadrao: true,
        custoPadrao: true,
      },
    }),

    prisma.produto.findMany({
      where: { status: "Ativo" },
      orderBy: [{ nome: "asc" }],
      select: {
        id: true,
        nome: true,
        categoria: true,
        unidade: true,
        quantidade: true,
        valorCompra: true,
        valorVenda: true,
        status: true,
      },
    }),

    prisma.kitProduto.findMany({
      where: { status: "Ativo" },
      orderBy: { nome: "asc" },
      include: {
        itens: {
          orderBy: [{ ordem: "asc" }, { id: "asc" }],
          include: {
            produto: {
              select: {
                id: true,
                nome: true,
                categoria: true,
                unidade: true,
                quantidade: true,
                valorCompra: true,
                valorVenda: true,
                status: true,
              },
            },
          },
        },
      },
    }),

    prisma.configuracaoClinica.findFirst({
      select: {
        horarioAtendimento: true,
      },
    }),
  ]);

  const profissionalDoUsuario = usuarioAdmin
    ? null
    : encontrarProfissionalDoUsuario(usuario, profissionais);

  const profissionalFiltro =
    profissionalFiltroParam && profissionalFiltroParam !== "todas"
      ? profissionalFiltroParam
      : profissionalDoUsuario
        ? String(profissionalDoUsuario.id)
        : "todas";

  const [agendamentos, bloqueios] = await Promise.all([
    prisma.agendamento.findMany({
      where: {
        data: {
          gte: inicioBusca,
          lt: fimBusca,
        },
      },
      include: {
        cliente: {
          select: {
            id: true,
            nome: true,
            telefone: true,
            whatsapp: true,
            cpf: true,
            nascimento: true,
            cep: true,
            logradouro: true,
            numero: true,
            complemento: true,
            bairro: true,
            cidade: true,
            estado: true,
            enderecoOriginal: true,
            observacoes: true,
          },
        },
        profissional: {
          select: {
            id: true,
            nome: true,
            area: true,
            cor: true,
            status: true,
          },
        },
      },
      orderBy: { data: "asc" },
    }),
    prisma.bloqueioAgenda.findMany({
      where: {
        data: {
          gte: inicioBusca,
          lt: fimBusca,
        },
        status: "Ativo",
      },
      include: {
        profissional: {
          select: {
            id: true,
            nome: true,
            area: true,
            cor: true,
            status: true,
          },
        },
      },
      orderBy: { data: "asc" },
    }),
  ]);

  return (
    <div className="w-full max-w-full overflow-x-hidden pb-0">
      <AgendaClient
        clientes={clientes}
        agendamentos={agendamentos.map((agendamento) => ({
          ...agendamento,
          naturezaAtendimento: normalizarNaturezaAtendimento(
            agendamento.naturezaAtendimento,
          ),
          data: agendamento.data.toISOString(),
          evolucaoPendenteDesde:
            agendamento.evolucaoPendenteDesde?.toISOString() || null,
          evolucaoRegistradaEm:
            agendamento.evolucaoRegistradaEm?.toISOString() || null,
          createdAt: agendamento.createdAt.toISOString(),
          updatedAt: agendamento.updatedAt.toISOString(),
          cliente: {
            ...agendamento.cliente,
            nascimento: agendamento.cliente.nascimento?.toISOString() || null,
          },
        }))}
        bloqueios={bloqueios.map((bloqueio) => ({
          ...bloqueio,
          data: bloqueio.data.toISOString(),
          createdAt: bloqueio.createdAt.toISOString(),
          updatedAt: bloqueio.updatedAt.toISOString(),
        }))}
        profissionais={profissionais}
        origensCliente={origensCliente}
        servicos={servicos}
        produtos={produtos}
        kits={kits}
        podeAutorizarEstoqueNegativo={usuarioAdmin}
        areaPadraoAgendamento={areaPadraoAgendamento}
        initialDate={toDateInput(dataSelecionada)}
        initialProfissionalFiltro={profissionalFiltro}
        initialClienteId={clienteIdParam}
        initialView={viewMode}
        horarioAtendimento={configuracaoClinica?.horarioAtendimento || null}
        podeEditarCliente={podeEditarCliente}
        podeRegistrarEvolucao={podeRegistrarEvolucao}
      />
    </div>
  );
}
