import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const permissoesPadrao = [
  { modulo: "Dashboard", nome: "Visualizar dashboard", chave: "dashboard.visualizar" },
  { modulo: "Clientes", nome: "Visualizar clientes", chave: "clientes.visualizar" },
  { modulo: "Clientes", nome: "Gerenciar clientes", chave: "clientes.gerenciar" },
  { modulo: "Clientes", nome: "Gerenciar ficha clínica", chave: "clientes.clinico" },
  { modulo: "Agenda", nome: "Visualizar agenda", chave: "agenda.visualizar" },
  { modulo: "Agenda", nome: "Gerenciar agendamentos", chave: "agenda.gerenciar" },
  { modulo: "Financeiro", nome: "Visualizar financeiro", chave: "financeiro.visualizar" },
  { modulo: "Financeiro", nome: "Gerenciar financeiro", chave: "financeiro.gerenciar" },
  { modulo: "Estoque", nome: "Visualizar estoque", chave: "estoque.visualizar" },
  { modulo: "Estoque", nome: "Gerenciar estoque", chave: "estoque.gerenciar" },
  { modulo: "Relatórios", nome: "Visualizar relatórios", chave: "relatorios.visualizar" },
  { modulo: "Marketing", nome: "Visualizar marketing", chave: "marketing.visualizar" },
  { modulo: "Marketing", nome: "Gerenciar marketing", chave: "marketing.gerenciar" },
  { modulo: "Configurações", nome: "Gerenciar configurações", chave: "configuracoes.gerenciar" },
  { modulo: "Usuários", nome: "Gerenciar usuários", chave: "usuarios.gerenciar" },
  { modulo: "Permissões", nome: "Gerenciar permissões", chave: "permissoes.gerenciar" },
  { modulo: "Auditoria", nome: "Visualizar auditoria", chave: "auditoria.visualizar" },
  { modulo: "Backup", nome: "Gerenciar backup", chave: "backup.gerenciar" },
  { modulo: "Automações", nome: "Gerenciar automações", chave: "automacoes.gerenciar" },
];

// 🔥 FIX RAILWAY SAFE (SEM VALIDAR SENHA NO BUILD)
function getSeedPassword(envName: string, fallback: string) {
  const password = process.env[envName]?.trim();

  // 🔥 Railway safe mode (não quebra build)
  if (!password) {
    return fallback;
  }

  return password;
}

function getAdminPassword() {
  return getSeedPassword("ADMIN_PASSWORD", "12345678");
}

function getOperationalPassword() {
  return getSeedPassword("OPERATIONAL_PASSWORD", "12345678");
}

async function main() {
  const adminEmail = (process.env.ADMIN_EMAIL || "admin@studiorealcar.com").trim().toLowerCase();
  const adminName = (process.env.ADMIN_NAME || "Administrador").trim();

  const operationalEmail = (process.env.OPERATIONAL_EMAIL || "operacional@studiorealcar.com").trim().toLowerCase();
  const operationalName = (process.env.OPERATIONAL_NAME || "Operacional").trim();

  const adminPassword = getAdminPassword();
  const operationalPassword = getOperationalPassword();

  const senhaHash = await bcrypt.hash(adminPassword, 10);
  const senhaOperacionalHash = await bcrypt.hash(operationalPassword, 10);

  // 🔥 permissões
  for (const permissao of permissoesPadrao) {
    await prisma.permissao.upsert({
      where: { chave: permissao.chave },
      update: { nome: permissao.nome, modulo: permissao.modulo },
      create: permissao,
    });
  }

  const perfilAdmin = await prisma.perfil.upsert({
    where: { nome: "Administrador" },
    update: {
      descricao: "Acesso total ao ERP.",
      nivel: 5,
      status: "Ativo",
    },
    create: {
      nome: "Administrador",
      descricao: "Acesso total ao ERP.",
      nivel: 5,
      status: "Ativo",
    },
  });

  const permissoes = await prisma.permissao.findMany({
    where: {
      chave: { in: permissoesPadrao.map((p) => p.chave) }
    },
  });

  for (const permissao of permissoes) {
    await prisma.perfilPermissao.upsert({
      where: {
        perfilId_permissaoId: {
          perfilId: perfilAdmin.id,
          permissaoId: permissao.id,
        },
      },
      update: {},
      create: {
        perfilId: perfilAdmin.id,
        permissaoId: permissao.id,
      },
    });
  }

  const perfilOperacional = await prisma.perfil.upsert({
    where: { nome: "Operacional" },
    update: {
      descricao: "Acesso restrito",
      nivel: 1,
      status: "Ativo",
    },
    create: {
      nome: "Operacional",
      descricao: "Acesso restrito",
      nivel: 1,
      status: "Ativo",
    },
  });

  const permissoesOperacionais = permissoes.filter((p) =>
    ["agenda.visualizar", "agenda.gerenciar", "clientes.visualizar", "clientes.gerenciar", "clientes.clinico"].includes(p.chave)
  );

  for (const permissao of permissoesOperacionais) {
    await prisma.perfilPermissao.upsert({
      where: {
        perfilId_permissaoId: {
          perfilId: perfilOperacional.id,
          permissaoId: permissao.id,
        },
      },
      update: {},
      create: {
        perfilId: perfilOperacional.id,
        permissaoId: permissao.id,
      },
    });
  }

  await prisma.usuario.upsert({
    where: { email: adminEmail },
    update: {
      nome: adminName,
      senha: senhaHash,
      tipo: "Admin",
      status: "Ativo",
      perfilId: perfilAdmin.id,
    },
    create: {
      nome: adminName,
      email: adminEmail,
      senha: senhaHash,
      tipo: "Admin",
      status: "Ativo",
      perfilId: perfilAdmin.id,
    },
  });

  await prisma.usuario.upsert({
    where: { email: operationalEmail },
    update: {
      nome: operationalName,
      senha: senhaOperacionalHash,
      tipo: "Equipe",
      status: "Ativo",
      perfilId: perfilOperacional.id,
    },
    create: {
      nome: operationalName,
      email: operationalEmail,
      senha: senhaOperacionalHash,
      tipo: "Equipe",
      status: "Ativo",
      perfilId: perfilOperacional.id,
    },
  });

  console.log("Seed concluído com sucesso 🚀");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });